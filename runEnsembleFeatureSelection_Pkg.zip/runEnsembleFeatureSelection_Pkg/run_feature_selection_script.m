% Script to run ensemble feature selection
% Written by: Kathrin Tyryshkin, Feb 2020
% Edited by: Tashifa Imtiaz, Oct 2024

% This script will run ensemble feature selection algorithm that is used in
% MFeaST without the app interface. 
% User should have the following toolboxes: 
        % Statistics and Machine Learning Toolbox
        % Parallel Computing Toolbox
        % Bioinformatics Toolbox
        % Deep Learning Toolbox

% The following custom functions are required: 
        % runFeatureSelect_v3
        % run_featureRankEnsemble
        % featureRankEnsemble_v3
        % greedyFeatureSelEnsamble
        % iterSequantialfs_v2
        % computeMI_hist
        % mutualInfo
        % computeFoldChange
        % minmax_standardize

% Algorithms available to run, copy paste and uncomment to assign
% selectedAlgs = ["MI","RankFeaturesROC","RankFeaturesWil",...
%                 "Relieff","TreeBagger","Fitctree","ensembleBag",...
%                 "ensembleGentleBoost","ensembleRUSBoost",...
%                 "Sequential_knn","Sequential_tree","Sequential_ensbl",...
%                 "Sequential_svm","Sequential_quadrLDA"];

% -------------------------------------------------------------------------
% Set up parameters to run feature selection
% -------------------------------------------------------------------------
UseParallel = true; % condition to use parallel pool
validationtype = 'KFold'; % 'KFold','HoldOut','LeaveOut','resubstitution'
k = 5; % for k-fold
IS_max_iterations = 5; % for sequential algorithms
isLogTransformed = false; % is your data log transformed?

% Choose algorithms to run. If want all algorithms, type "All" otherwise
% write out the individual algorithms you would like to run
selectedAlgs = ["MI"];

if strcmp(selectedAlgs,'All')
    selectedAlgs = ["MI","RankFeaturesROC","RankFeaturesWil",...
                "Relieff","TreeBagger","Fitctree","ensembleBag",...
                "ensembleGentleBoost","ensembleRUSBoost",...
                "Sequential_knn","Sequential_tree","Sequential_ensbl",...
                "Sequential_svm","Sequential_quadrLDA"];
end

% -------------------------------------------------------------------------
% Load in and format the data for feature selection function
% -------------------------------------------------------------------------
dat = readcell('miRNAdata_example.xlsx'); 
saveFileAs = 'example_results'; % file name to save as (without the file type suffix)
% Note: data should be formatted with header columns 

col_start = 2; % starting column of numeric data
row_start = 5; % starting row of numeric data

sample_row = 1; % row containing sample ids
cat_row = 4; % row containing the categorical class information for the comparison 
ft_col = 1; % column containing the feature ids, in case dat has multiple header columns

comparisonClass1 = {'MCC'}; % class label of the first class you want to compare
comparisonClass2 = {'NB'}; % class label of the second class you want to compare

% Identify only those samples with the corresponding class names indicated
idx_samples = ismember(dat(cat_row,col_start:end),[comparisonClass1,comparisonClass2]); 

% Prepare data for feature selection app with following parts: 
ft_col = [{'Features'};dat(row_start:end,ft_col)]; % column name followed by feature names, must be cell array of characters
cat_row = dat(cat_row,[false(1,col_start-1),idx_samples]); % only the class information for the samples selected for comparison
dat_row = dat(row_start:end,[false(1,col_start-1),idx_samples]); % only the numeric data for the samples selected for comparison

% Combine into data for feature selection.
data2use = [ft_col,[cat_row;dat_row]]; 
% data2use is a cell array with the first row as the class labels, first
% column as a the feature labels, and the remaining aka.
% data2use(2:end,2:end) as numeric values. 

% -------------------------------------------------------------------------
% Run feature selection
% -------------------------------------------------------------------------
[ranked_features, celldata_ranked] = runFeatureSelect_v3(...
    data2use,cat_row', validationtype,k, UseParallel, ...
    IS_max_iterations, selectedAlgs, isLogTransformed); 

% Write results to excel file
writecell(ranked_features,[saveFileAs '.xlsx'],'Sheet','RankedFeatures','WriteMode','replacefile')
writecell(ranked_features,[saveFileAs '.xlsx'],'Sheet','CellDataRanked')
